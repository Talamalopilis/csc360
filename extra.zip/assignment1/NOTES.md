# Producer/ Consumer Server
Implemented ADD, REMOVE, and SUM commands.

# Client Test
Spins up multiple http threads to test the server.
Each thread psuedo randomly selects an operation. 
Run with `python clientTest.py`

Configurable with:
number of threads,
Distribution of thread operations,
range of values.

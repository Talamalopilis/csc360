#ifndef _REQUESTS_H_
#define _REQUESTS_H_

typedef enum {UNKNOWN, REMOVE, ADD, SUM, DEBUG} pc_op_t;

#endif
